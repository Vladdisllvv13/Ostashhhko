﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using MathTaskClassLibrary1;

namespace MathTaskClassLibraryTests
{
    [TestClass]
    public class GeometryTests
    {
        [TestMethod]
        public void TestMethod()
        {
            int a = 3;
            int b = 5;
            int rectangleExpected = 15;

            double r = 5;
            double h = 3.54;
            double cylinderExpected = 277.89;

            Geometry g = new Geometry();

            int rectangleActual =  g.RectangleArea(a, b);
            double cylinderActual = g.CylinderArea(r, h);

            Assert.AreEqual(rectangleExpected, rectangleActual);
            Assert.AreEqual(cylinderExpected, cylinderActual);
        }
    }
}
