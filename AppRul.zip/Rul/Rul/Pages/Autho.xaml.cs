﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Rul.Entities;

namespace Rul.Pages
{
    /// <summary>
    /// Логика взаимодействия для Autho.xaml
    /// </summary>
    public partial class Autho : Page
    {
        private DispatcherTimer _timer;


        private static int _badcaptcha = 0;
        private static int _falsecount = 0;
        public Autho()
        {
            InitializeComponent();
            //hide our captcha items
            txtCaptcha.Visibility = Visibility.Hidden;
            textBlockCaptcha.Visibility = Visibility.Hidden;
        }

        private void btnEnterGuest_Click(object sender, RoutedEventArgs e)
        {
            //jump to client from not registered user
            NavigationService.Navigate(new Client()); 
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            //check user login and password and jump to user's role page

            User user = RullEntities.GetContext().User.Where(l => l.UserLogin == txtLogin.Text && l.UserPassword == txtPassword.Text).FirstOrDefault();

            if (_falsecount != 2)
            {
                if (user != null) SuccessAutentification(user);
                else
                {
                    _falsecount++;
                    MessageBox.Show("Неправильно введен логин или пароль");
                    if (_falsecount == 2) GenerateCaptcha();
                }
            }
            else
            {
                txtCaptcha.Visibility = Visibility.Visible;
                textBlockCaptcha.Visibility = Visibility.Visible;

                if (txtCaptcha.Text == textBlockCaptcha.Text && user != null) SuccessAutentification(user);
                else
                {
                    GenerateCaptcha();
                    MessageBox.Show("Похоже, что вы робот");
                    _badcaptcha++;
                    if (_badcaptcha >= 3)
                    {
                        _timer = new DispatcherTimer();
                        _timer.Interval = new TimeSpan(0,0,1);
                        _timer.Tick += TimerTick;
                        _timer.Start();
                        btnEnter.IsEnabled = true;
                        txtCaptcha.IsEnabled = true;

                        MessageBox.Show("Держите блок на 10 секунд");
                    }
                }
            }
        }

        private void GenerateCaptcha()
        {
            txtCaptcha.Text = "";
            string captchavalue = "";
            Random rnd = new Random();
            StringBuilder captchaitems = new StringBuilder();
            captchaitems.Append("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
            captchaitems.Append("ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToLower());
            captchaitems.Append("1234567890");
            for (int i = 0; i < 8; i++)
            {
                captchavalue += captchaitems[rnd.Next(0, captchaitems.Length)];
            }
            textBlockCaptcha.Text = captchavalue;
        }

        private void SuccessAutentification(User user)
        {
            txtCaptcha.Visibility = Visibility.Hidden;
            textBlockCaptcha.Visibility = Visibility.Hidden;
            _badcaptcha = 0;
            _falsecount = 0;
            MessageBox.Show("Поздравления");
            switch (user.UserRole)
            {
                case 1:

                    break;
                case 2:
                    break;
                case 3:
                    break;
            }
            _falsecount = 0;
        }

        private void TimerTick(object sender, EventArgs e)
        {
            
            btnEnter.IsEnabled = false;
            txtCaptcha.IsEnabled = false;
            _timer.Stop();
        }
    }
}
